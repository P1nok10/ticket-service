package com.service.tickets.repository;

import com.service.tickets.model.RequestAccess;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestAccessRepository extends JpaRepository<RequestAccess, Long> {
}
