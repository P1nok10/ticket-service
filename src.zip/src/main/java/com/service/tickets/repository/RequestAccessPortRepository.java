package com.service.tickets.repository;

import com.service.tickets.model.RequestAccessPort;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestAccessPortRepository extends JpaRepository<RequestAccessPort, Long> {
}
