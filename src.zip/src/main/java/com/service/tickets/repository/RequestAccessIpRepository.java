package com.service.tickets.repository;

import com.service.tickets.model.RequestAccessIp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestAccessIpRepository extends JpaRepository<RequestAccessIp, Long> {
}
