package com.service.tickets.repository.Flux;

import com.service.tickets.model.Flux.Ip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IpRepository extends JpaRepository<Ip, Long> {
    // Custom query methods can be added here
}