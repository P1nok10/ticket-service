package com.service.tickets.repository.Flux;

import com.service.tickets.model.Flux.Port;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PortRepository extends JpaRepository<Port, Long> {
    // Custom query methods can be added here
}