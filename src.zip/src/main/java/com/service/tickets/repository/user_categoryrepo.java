package com.service.tickets.repository;

import com.service.tickets.model.USER_CATEGORY;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface user_categoryrepo extends CrudRepository<USER_CATEGORY, Long> {
}
