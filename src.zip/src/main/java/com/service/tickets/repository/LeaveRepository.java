package com.service.tickets.repository;

import com.service.tickets.model.Leave;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface LeaveRepository extends JpaRepository<Leave, Long> {
}