package com.service.tickets.repository;

import com.service.tickets.model.RequestAccessDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestAccessDetailRepository extends JpaRepository<RequestAccessDetail, Long> {
}
