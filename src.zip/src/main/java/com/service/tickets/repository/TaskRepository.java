package com.service.tickets.repository;

import com.service.tickets.model.Tasks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TaskRepository extends CrudRepository<Tasks, Long> {
}