package com.service.tickets.repository.Flux;

import com.service.tickets.model.Flux.RequestFlux;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestFluxRepository extends JpaRepository<RequestFlux, Long> {
    // Custom query methods can be added here
}