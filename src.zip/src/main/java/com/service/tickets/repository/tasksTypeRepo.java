package com.service.tickets.repository;

import com.service.tickets.model.tasks_type;
import org.springframework.data.repository.CrudRepository;

public interface tasksTypeRepo extends CrudRepository<tasks_type, Long> {
}
