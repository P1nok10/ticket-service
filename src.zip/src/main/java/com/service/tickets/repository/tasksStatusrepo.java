package com.service.tickets.repository;

import com.service.tickets.model.tasks_status;
import org.springframework.data.repository.CrudRepository;

public interface tasksStatusrepo extends CrudRepository<tasks_status, Long> {
}
