package com.service.tickets.repository.Flux;

import com.service.tickets.model.Flux.RequestFluxDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestFluxDetailRepository extends JpaRepository<RequestFluxDetail, Long> {
    // Custom query methods can be added here
}