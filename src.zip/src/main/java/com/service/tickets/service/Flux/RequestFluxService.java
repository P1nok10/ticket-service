package com.service.tickets.service.Flux;

import com.service.tickets.model.Flux.RequestFlux;
import com.service.tickets.repository.Flux.RequestFluxRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RequestFluxService {
    @Autowired
    private RequestFluxRepository requestFluxRepository;

    public List<RequestFlux> getAllRequestFluxes() {
        return requestFluxRepository.findAll();
    }

    public RequestFlux getRequestFlux(Long id) {
        return requestFluxRepository.findById(id).orElseThrow();
    }

    public RequestFlux createRequestFlux(RequestFlux requestFlux) {
        return requestFluxRepository.save(requestFlux);
    }

    public RequestFlux updateRequestFlux(Long id, RequestFlux requestFlux) {
        return requestFluxRepository.save(requestFlux);
    }

    public void deleteRequestFlux(Long id) {
        requestFluxRepository.deleteById(id);
    }
}