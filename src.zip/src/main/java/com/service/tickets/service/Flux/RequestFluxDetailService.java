package com.service.tickets.service.Flux;

import com.service.tickets.model.Flux.RequestFluxDetail;
import com.service.tickets.repository.Flux.RequestFluxDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RequestFluxDetailService {
    @Autowired
    private RequestFluxDetailRepository requestFluxDetailRepository;

    public List<RequestFluxDetail> getAllRequestFluxDetails() {
        return requestFluxDetailRepository.findAll();
    }

    public RequestFluxDetail getRequestFluxDetail(Long id) {
        return requestFluxDetailRepository.findById(id).orElseThrow();
    }

    public RequestFluxDetail createRequestFluxDetail(RequestFluxDetail requestFluxDetail) {
        return requestFluxDetailRepository.save(requestFluxDetail);
    }

    public RequestFluxDetail updateRequestFluxDetail(Long id, RequestFluxDetail requestFluxDetail) {
        return requestFluxDetailRepository.save(requestFluxDetail);
    }

    public void deleteRequestFluxDetail(Long id) {
        requestFluxDetailRepository.deleteById(id);
    }
}