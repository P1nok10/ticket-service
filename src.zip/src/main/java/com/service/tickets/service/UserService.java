package com.service.tickets.service;

import com.service.tickets.model.Role;
import com.service.tickets.model.User;
import com.service.tickets.model.UserDto;
import com.service.tickets.model.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService {

    // Saves a user
    User save(User user);

    // Retrieves all users
    List<User> findAll();

    // Retrieves a user by username
    User findByUsername(String username);

    User createEmployee(User user);

    User updateUser(Long id, UserDto userDto);

    void delete(User user);

    User findById(Long id);
}