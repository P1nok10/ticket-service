/*
package com.service.service.service.impl;

import com.service.service.model.Tasks;
import com.service.service.model.tasks_status;
import com.service.service.repository.TaskRepository;
import com.service.service.service.TasksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
public class TasksServiceImpl implements TasksService {

    @Autowired
    private TaskRepository tasksRepository;

    @Override
    public List<Tasks> getAllTasks() {
        return tasksRepository.findAll();
    }

    @Override
    public Tasks getTaskById(Long id) {
        return tasksRepository.findById(id).orElseThrow(() -> new RuntimeException("Task not found"));
    }

    @Override
    public Tasks createTask(Tasks task) {
        return tasksRepository.save(task);
    }

    @Override
    public Tasks updateTask(Long id, Tasks task) {
        Tasks existingTask = getTaskById(id);
        existingTask.setTitle(task.getTitle());
        existingTask.setDescription(task.getDescription());
    */
/*    existingTask.setType(task.getType());
        existingTask.setStatus(task.getStatus());*//*

        existingTask.setAction(task.getAction());
        existingTask.setResponsableId(task.getResponsableId());
        existingTask.setChDev(task.getChDev());
        existingTask.setChifrage(task.getChifrage());
        existingTask.setDevTig(task.getDevTig());
        existingTask.setLivraisonTig(task.getLivraisonTig());
        existingTask.setDateReponse(task.getDateReponse());
        existingTask.setAst(task.getAst());
        existingTask.setComment(task.getComment());
        return tasksRepository.save(existingTask);
    }

    @Override
    public void deleteTask(Long id) {
        tasksRepository.deleteById(id);
    }

    public Tasks updateTaskStatus(Long id, tasks_status newStatus) {
        Tasks task = tasksRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("Task not found"));
      */
/*  task.setStatus(newStatus);*//*

        return tasksRepository.save(task);
    }

}*/
