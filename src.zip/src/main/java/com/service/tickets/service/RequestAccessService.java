package com.service.tickets.service;

import com.service.tickets.model.*;
import com.service.tickets.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.service.tickets.*;

@Service
public class RequestAccessService {
    @Autowired
    private UserRepo userRepository ;

    @Autowired
    private RequestAccessRepository requestAccessRepository;

    @Autowired
    private RequestAccessDetailRepository requestAccessDetailRepository;

    @Autowired
    private RequestAccessIpRepository requestAccessIpRepository;

    @Autowired
    private RequestAccessPortRepository requestAccessPortRepository;

    public void createRequestAccess(User user, String env, String module, String ipNumber, String ipDescription, Integer portNumber, String portDescription) {
        RequestAccess requestAccess = new RequestAccess();
        requestAccess.setUser(user);
        requestAccessRepository.save(requestAccess);

        RequestAccessDetail requestAccessDetail = new RequestAccessDetail();
        requestAccessDetail.setRequestAccess(requestAccess);
        requestAccessDetail.setEnv(env);
        requestAccessDetail.setModule(module);
        requestAccessDetailRepository.save(requestAccessDetail);

        RequestAccessIp requestAccessIp = new RequestAccessIp();
        requestAccessIp.setRequestAccess(requestAccess);
        requestAccessIp.setIpNumber(ipNumber);
        requestAccessIp.setIpDescription(ipDescription);
        requestAccessIpRepository.save(requestAccessIp);

        RequestAccessPort requestAccessPort = new RequestAccessPort();
        requestAccessPort.setRequestAccess(requestAccess);
        requestAccessPort.setPortNumber(portNumber);
        requestAccessPort.setPortDescription(portDescription);
        requestAccessPortRepository.save(requestAccessPort);
    }
}