package com.service.tickets.service.impl;

import com.service.tickets.model.Role;
import com.service.tickets.repository.RoleRepo;
import com.service.tickets.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service(value = "roleService")
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleRepo roleRepo;

    @Override
    public Role findByName(String name) {
        // Find role by name using the roleRepo
        return roleRepo.findRoleByName(name);
    }

    @Override
    public ArrayList<Role> findAll() {
        return (ArrayList<Role>) roleRepo.findAll();
    }
}
