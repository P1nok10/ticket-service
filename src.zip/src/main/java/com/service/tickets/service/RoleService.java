package com.service.tickets.service;

// Importing the Role model
import com.service.tickets.model.Role;

import java.util.ArrayList;

// Declaring the RoleService interface
public interface RoleService {
    // Method to find a Role by its name
    Role findByName(String name);
    ArrayList<Role> findAll();
}
