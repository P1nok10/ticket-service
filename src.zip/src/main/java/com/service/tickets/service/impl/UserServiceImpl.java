package com.service.tickets.service.impl;

import java.util.*;

import com.service.tickets.Exception.ResourceNotFoundException;
import com.service.tickets.model.Role;
import com.service.tickets.model.USER_CATEGORY;
import com.service.tickets.repository.UserRepo;
import com.service.tickets.model.User;
import com.service.tickets.model.UserDto;
import com.service.tickets.service.RoleService;
import com.service.tickets.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, UserService {

    @Autowired
    private RoleService roleService;



    @Autowired
    private UserRepo userRepo;

    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;

    // Load user by username
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepo.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority(user));
    }
    //load user by login vpn
    public User loadUserByLoginVpn(String loginVpn) throws UsernameNotFoundException {
        User user = userRepo.findByVpnLogin(loginVpn);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        return user;
    }

    // Get user authorities
    private Set<SimpleGrantedAuthority> getAuthority(User user) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();

            authorities.add(new SimpleGrantedAuthority("ROLE_" + user.getRoles().getName()));

        return authorities;
    }

    // Find all users
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        userRepo.findAll().iterator().forEachRemaining(list::add);
        return list;
    }

    // Find user by username
    @Override
    public User findByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    // Save user
    @Override
    public User save(User user) {
        if (userRepo.existsById(user.getId())) {
            throw new IllegalArgumentException("User with ID " + user.getId() + " already exists");
        }

        // Encrypt password
        user.setPassword(bcryptEncoder.encode(user.getPassword()));

        //save default role as admin
        user.setRoles(user.getRoles());

        return userRepo.save(user);
    }

    @Override
    public User createEmployee(User user) {

        user.setPassword(bcryptEncoder.encode(user.getPassword()));

        Role employeeRole = roleService.findByName("ADMIN");
        Role customerRole = roleService.findByName("USER");


        user.setRoles(customerRole);
        return userRepo.save(user);
    }

    @Override
    public User updateUser(Long id, UserDto userDto) {
        User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setUsername(userDto.getUsername());
        user.setVpnLogin(userDto.getVpnLogin());
        user.setVpnDeviceNumber(userDto.getVpnDeviceNumber());
        user.setPassword(userDto.getPassword());

        return userRepo.save(user);
    }

    @Override
    public void delete(User user) {
        userRepo.delete(user);
    }

    @Override
    public User findById(Long id) {
        return userRepo.findById(id).orElse(null);
    }
}