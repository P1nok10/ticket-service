package com.service.tickets.service.Flux;

import com.service.tickets.model.Flux.Port;
import com.service.tickets.repository.Flux.PortRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PortService {
    @Autowired
    private PortRepository portRepository;

    public List<Port> getAllPorts() {
        return portRepository.findAll();
    }

    public Port getPort(Long id) {
        return portRepository.findById(id).orElseThrow();
    }

    public Port createPort(Port port) {
        return portRepository.save(port);
    }

    public Port updatePort(Long id, Port port) {
        return portRepository.save(port);
    }

    public void deletePort(Long id) {
        portRepository.deleteById(id);
    }
}