package com.service.tickets.service.Flux;

import com.service.tickets.model.Flux.Ip;
import com.service.tickets.repository.Flux.IpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IpService {
    @Autowired
    private IpRepository ipRepository;

    public List<Ip> getAllIps() {
        return ipRepository.findAll();
    }

    public Ip getIp(Long id) {
        return ipRepository.findById(id).orElseThrow();
    }

    public Ip createIp(Ip ip) {
        return ipRepository.save(ip);
    }

    public Ip updateIp(Long id, Ip ip) {
        return ipRepository.save(ip);
    }

    public void deleteIp(Long id) {
        ipRepository.deleteById(id);
    }
}