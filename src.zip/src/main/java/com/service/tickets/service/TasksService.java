package com.service.tickets.service;

import com.service.tickets.model.Tasks;
import com.service.tickets.model.tasks_status;

import java.util.List;

public interface TasksService {

    Tasks createTask(Tasks task);

    List<Tasks> getAllTasks();

    Tasks getTaskById(Long id);

    Tasks updateTask(Long id, Tasks updatedTask);

    void deleteTask(Long id);

    Tasks updateTaskStatus(Long id, tasks_status newStatus);
}