/*
package com.service.service.controller;

import com.service.service.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private TaskRepository taskRepository;

    @GetMapping("/overview")
    public ResponseEntity<Map<String, Object>> getDashboardOverview() {
        Map<String, Object> response = new HashMap<>();
        response.put("totalTasks", taskRepository.count());
        response.put("completedTasks", taskRepository.countByStatus("completed"));
        response.put("inProgressTasks", taskRepository.countByStatus("in progress"));
        response.put("pendingTasks", taskRepository.countByStatus("pending"));

        return ResponseEntity.ok(response);
    }
}
*/
