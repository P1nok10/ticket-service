/*
package com.service.service.controller;

import com.service.service.model.Tasks;
import com.service.service.service.TasksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TasksController {

    @Autowired
    private TasksService tasksService;

    @PostMapping
    public ResponseEntity<Tasks> createTask(@RequestBody Tasks task) {
        return new ResponseEntity<>(tasksService.createTask(task), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Tasks>> getAllTasks() {
        return new ResponseEntity<>(tasksService.getAllTasks(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tasks> getTaskById(@PathVariable Long id) {
        return new ResponseEntity<>(tasksService.getTaskById(id), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tasks> updateTask(@PathVariable Long id, @RequestBody Tasks updatedTask) {
        return new ResponseEntity<>(tasksService.updateTask(id, updatedTask), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable Long id) {
        tasksService.deleteTask(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Tasks> updateTaskStatus(@PathVariable Long id, @RequestParam String status) {
        Tasks updatedTask = tasksService.updateTaskStatus(id, status);
        return ResponseEntity.ok(updatedTask);
    }
}*/
