package com.service.tickets.controller;

import com.service.tickets.model.User;
import com.service.tickets.service.RequestAccessService;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.service.tickets.repository.UserRepo;
@RestController
@RequestMapping("/api")
public class RequestAccessController {
    @Autowired
    private RequestAccessService requestAccessService;

    @Autowired
    private UserRepo userRepo;

    @PostMapping("/request-access")
    public ResponseEntity<?> createRequestAccess(@RequestBody RequestAccessRequest request) {
        User user = userRepo.findByUsername(request.getLoginVpn());
        requestAccessService.createRequestAccess(user, request.getEnv(), request.getModule(), request.getIpNumber(), request.getIpDescription(), request.getPortNumber(), request.getPortDescription());
        return ResponseEntity.ok().build();
    }
}

@Getter
@Setter
class RequestAccessRequest {
    private String loginVpn;
    private String env;
    private String module;
    private String ipNumber;
    private String ipDescription;
    private Integer portNumber;
    private String portDescription;

    // Getters and setters
}
