package com.service.tickets.controller;

import com.service.tickets.model.dto.RequestFluxCreationRequest;
import com.service.tickets.model.Flux.Ip;
import com.service.tickets.model.Flux.Port;
import com.service.tickets.model.Flux.RequestFlux;
import com.service.tickets.model.Flux.RequestFluxDetail;
import com.service.tickets.service.Flux.IpService;
import com.service.tickets.service.Flux.PortService;
import com.service.tickets.service.Flux.RequestFluxDetailService;
import com.service.tickets.service.Flux.RequestFluxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RequestFluxController {
    @Autowired
    private RequestFluxService requestFluxService;
    @Autowired
    private RequestFluxDetailService requestFluxDetailService;
    @Autowired
    private IpService ipService;
    @Autowired
    private PortService portService;

    @GetMapping("/request-flux")
    public List<RequestFlux> getAllRequestFluxes() {
        return requestFluxService.getAllRequestFluxes();
    }

    @GetMapping("/request-flux/{id}")
    public RequestFlux getRequestFlux(@PathVariable Long id) {
        return requestFluxService.getRequestFlux(id);
    }

    @PostMapping("/request-flux")
    public RequestFlux createRequestFlux(@RequestBody RequestFlux requestFlux) {
        return requestFluxService.createRequestFlux(requestFlux);
    }

    @PutMapping("/request-flux/{id}")
    public RequestFlux updateRequestFlux(@PathVariable Long id, @RequestBody RequestFlux requestFlux) {
        return requestFluxService.updateRequestFlux(id, requestFlux);
    }

    @DeleteMapping("/request-flux/{id}")
    public void deleteRequestFlux(@PathVariable Long id) {
        requestFluxService.deleteRequestFlux(id);
    }

    @GetMapping("/request-flux-detail")
    public List<RequestFluxDetail> getAllRequestFluxDetails() {
        return requestFluxDetailService.getAllRequestFluxDetails();
    }

    @GetMapping("/request-flux-detail/{id}")
    public RequestFluxDetail getRequestFluxDetail(@PathVariable Long id) {
        return requestFluxDetailService.getRequestFluxDetail(id);
    }

    @PostMapping("/request-flux-detail")
    public RequestFluxDetail createRequestFluxDetail(@RequestBody RequestFluxDetail requestFluxDetail) {
        return requestFluxDetailService.createRequestFluxDetail(requestFluxDetail);
    }

    @PutMapping("/request-flux-detail/{id}")
    public RequestFluxDetail updateRequestFluxDetail(@PathVariable Long id, @RequestBody RequestFluxDetail requestFluxDetail) {
        return requestFluxDetailService.updateRequestFluxDetail(id, requestFluxDetail);
    }

    @DeleteMapping("/request-flux-detail/{id}")
    public void deleteRequestFluxDetail(@PathVariable Long id) {
        requestFluxDetailService.deleteRequestFluxDetail(id);
    }

    @GetMapping("/ip")
    public List<Ip> getAllIps() {
        return ipService.getAllIps();
    }

    @GetMapping("/ip/{id}")
    public Ip getIp(@PathVariable Long id) {
        return ipService.getIp(id);
    }

    @PostMapping("/ip")
    public Ip createIp(@RequestBody Ip ip) {
        return ipService.createIp(ip);
    }

    @PutMapping("/ip/{id}")
    public Ip updateIp(@PathVariable Long id, @RequestBody Ip ip) {
        return ipService.updateIp(id, ip);
    }

    @DeleteMapping("/ip/{id}")
    public void deleteIp(@PathVariable Long id) {
        ipService.deleteIp(id);
    }

    @GetMapping("/port")
    public List<Port> getAllPorts() {
        return portService.getAllPorts();
    }

    @GetMapping("/port/{id}")
    public Port getPort(@PathVariable Long id) {
        return portService.getPort(id);
    }

    @PostMapping("/port")
    public Port createPort(@RequestBody Port port) {
        return portService.createPort(port);
    }

    @PutMapping("/port/{id}")
    public Port updatePort(@PathVariable Long id, @RequestBody Port port) {
        return portService.updatePort(id, port);
    }

    @DeleteMapping("/port/{id}")
    public void deletePort(@PathVariable Long id) {
        portService.deletePort(id);
    }

    @PostMapping("/request-flux-with-details")
    public RequestFlux createRequestFluxWithDetails(@RequestBody RequestFluxCreationRequest request) {
        // Create the RequestFlux entity
        RequestFlux createdRequestFlux = requestFluxService.createRequestFlux(request.getRequestFlux());

        // Create associated RequestFluxDetails
        for (RequestFluxDetail detail : request.getRequestFluxDetails()) {
            detail.setRequestFlux(createdRequestFlux);
            requestFluxDetailService.createRequestFluxDetail(detail);
        }

        // Create associated Ip entities
        for (Ip ip : request.getIps()) {
            ipService.createIp(ip);
        }

        // Create associated Port entities
        for (Port port : request.getPorts()) {
            portService.createPort(port);
        }

        return createdRequestFlux;
    }
}
