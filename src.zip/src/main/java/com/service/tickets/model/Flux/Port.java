package com.service.tickets.model.Flux;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
public class Port {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String port;

    @ManyToOne
    @JoinColumn(name = "ip_id", referencedColumnName = "id")
    private Ip ip;

    // getters and setters
}