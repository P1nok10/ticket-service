package com.service.tickets.model;

import javax.persistence.*;
/*import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;*/
import java.util.Date;
import lombok.Getter;
import lombok.Setter;


@Entity
@Setter
@Getter
@Table(name = "tasks")
public class Tasks {
    @Getter
    @Setter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Getter
    @Setter
    @Column
    private String title;

    @Getter
    @Setter
    @Column
    private String description;

    @ManyToOne
    @JoinColumn(name = "task_type_id")
    private tasks_type type;
/*    @Getter
    @Setter
    @Column
    private String type;*/

    @Getter
    @Setter
    @Column
    private String action;

    @Getter
    @Setter
    @Column(name = "responsable")
    private Long responsableId;

    @ManyToOne
    @JoinColumn(name = "responsable", insertable = false, updatable = false)
    private User responsable;

    @Getter
    @Setter
    @Column
    private Integer chDev;

    @Getter
    @Setter
    @Column
    private Integer chifrage;

    @Getter
    @Setter
    @Column(name = "dev_tig")
    private Date devTig;

    @Getter
    @Setter
    @Column(name = "livraison_tig")
    private Date livraisonTig;

    @Getter
    @Setter
    @Column(name = "date_reponse")
    private Date dateReponse;

    @Getter
    @Setter
    @Column
    private String ast;

    @Getter
    @Setter
    @Column(name = "comment")
    private String comment;

   @ManyToOne
    @JoinColumn(name = "task_status_id")
    private tasks_status status;
 /*   @Column(name = "status")
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }*/

    // getters and setters
}