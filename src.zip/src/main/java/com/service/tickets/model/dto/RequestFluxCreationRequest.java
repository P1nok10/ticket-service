package com.service.tickets.model.dto;

import com.service.tickets.model.Flux.RequestFlux;
import com.service.tickets.model.Flux.RequestFluxDetail;
import com.service.tickets.model.Flux.Ip;
import com.service.tickets.model.Flux.Port;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class RequestFluxCreationRequest {
    private RequestFlux requestFlux;
    private List<RequestFluxDetail> requestFluxDetails;
    private List<Ip> ips;
    private List<Port> ports;

    // Getters and setters
    public RequestFlux getRequestFlux() {
        return requestFlux;
    }

    public void setRequestFlux(RequestFlux requestFlux) {
        this.requestFlux = requestFlux;
    }

    public List<RequestFluxDetail> getRequestFluxDetails() {
        return requestFluxDetails;
    }

    public void setRequestFluxDetails(List<RequestFluxDetail> requestFluxDetails) {
        this.requestFluxDetails = requestFluxDetails;
    }

    public List<Ip> getIps() {
        return ips;
    }

    public void setIps(List<Ip> ips) {
        this.ips = ips;
    }

    public List<Port> getPorts() {
        return ports;
    }

    public void setPorts(List<Port> ports) {
        this.ports = ports;
    }
}
