package com.service.tickets.model;

public class UserDto {
    
    private String username;
    private String password;
    private String vpnLogin;
    private String vpnDeviceNumber;
    private String firstName;
    private String lastName;
    private Long id;

    public UserDto(Long id) {
        this.id = id;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVpnLogin() {
        return vpnLogin;
    }

    public void setVpnLogin(String vpnLogin) {
        this.vpnLogin = vpnLogin;
    }

    public String getVpnDeviceNumber() {
        return vpnDeviceNumber;
    }

    public void setVpnDeviceNumber(String vpnDeviceNumber) {
        this.vpnDeviceNumber = vpnDeviceNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public User getUserFromDto(){
        User user = new User();
        user.setId(id);
        user.setUsername(username);
        user.setPassword(password);
        user.setVpnLogin(vpnLogin);
        user.setVpnDeviceNumber(vpnDeviceNumber);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        return user;
    }

    public Long getId() {
        return id;
    }
}