package com.service.tickets.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "request_access_detail")
public class RequestAccessDetail {
    @Id@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "request_access_id", nullable = false)
    private RequestAccess requestAccess;

    private String env;
    private String module;

    // Getters and setters
}