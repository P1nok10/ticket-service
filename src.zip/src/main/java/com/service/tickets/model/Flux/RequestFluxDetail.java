package com.service.tickets.model.Flux;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
public class RequestFluxDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String ipSource;
    private String identificationSource;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ip_id", referencedColumnName = "id")
    private Ip ip;

    @ManyToOne
    @JoinColumn(name = "request_flux_id", referencedColumnName = "id")
    private RequestFlux requestFlux;

    // getters and setters
}