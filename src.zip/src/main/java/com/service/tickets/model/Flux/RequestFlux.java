package com.service.tickets.model.Flux;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "RequestFlux")
public class RequestFlux {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "request_flux_detail_id", referencedColumnName = "id")
    private RequestFluxDetail requestFluxDetail;

    // getters and setters
}
