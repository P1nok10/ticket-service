package com.service.tickets.model.Flux;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
public class Ip {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String address;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "ip_id")
    private List<Port> ports;

    @OneToOne(mappedBy = "ip")
    private RequestFluxDetail requestFluxDetail;

    // getters and setters
}
