package com.service.tickets.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "request_access_port")
public class RequestAccessPort {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "request_access_id", nullable = false)
    private RequestAccess requestAccess;

    private Integer portNumber;
    private String portDescription;

    // Getters and setters
}